# ORBIX for Windows

    npm install
    npm start          run
    npm run dist       build installer + portable exe into dist\

Tray menu: Open ORBIX · Start focus session · Today's schedule · Start gaming timer ·
What should I do now? · Widgets · Pause notifications · Exit.

Global shortcuts (work when minimised): Ctrl+Shift+S start study, Ctrl+Shift+G gaming timer,
Ctrl+Shift+F focus mode, Ctrl+Shift+T today's schedule. Inside the window, Ctrl+K opens the
command palette.

Widgets are small always-on-top windows loading the same file with `?widget=study|next|exam|game`.

Optional site blocking is deliberately advisory: ORBIX reminds you and hides your list,
it does not seize control of your machine. If you want hard blocking, add the sites to your
hosts file yourself — the app will never edit it.
