const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('ORBIXDesktop',{
  platform:'windows',
  onCommand:cb=>ipcRenderer.on('studyflow',(_e,cmd)=>cb(cmd)),
  quit:()=>ipcRenderer.send('sf-quit')
});
