/* ORBIX — Windows desktop shell (Electron)
   Adds: system tray, global shortcuts, always-on-top widgets, single instance. */
const {app,BrowserWindow,Tray,Menu,globalShortcut,nativeImage,ipcMain,shell}=require('electron');
const path=require('path');

// Keep it light on older machines
app.commandLine.appendSwitch('disable-smooth-scrolling');
app.disableDomainBlockingFor3DAPIs&&app.disableDomainBlockingFor3DAPIs();

let win=null,tray=null,widgets={},quitting=false,notifPaused=false;
const APP=path.join(__dirname,'..','app','index.html');
const ICON=path.join(__dirname,'icon.png');

function createWindow(){
  win=new BrowserWindow({
    width:1180,height:780,minWidth:360,minHeight:520,
    backgroundColor:'#0F1524',show:false,autoHideMenuBar:true,
    icon:ICON,
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,spellcheck:false,backgroundThrottling:false}
  });
  win.loadFile(APP);
  win.once('ready-to-show',()=>win.show());
  win.on('close',e=>{ if(!quitting){ e.preventDefault(); win.hide(); } });
  win.webContents.setWindowOpenHandler(({url})=>{ shell.openExternal(url); return {action:'deny'} });
}

function send(cmd){ if(!win) return; win.show(); win.focus(); win.webContents.send('studyflow',cmd); }

function widget(name){
  if(widgets[name]&&!widgets[name].isDestroyed()){ widgets[name].focus(); return }
  const w=new BrowserWindow({
    width:260,height:150,frame:false,resizable:false,alwaysOnTop:true,skipTaskbar:true,
    transparent:false,backgroundColor:'#161E31',
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true}
  });
  w.loadFile(APP,{query:{widget:name}});
  widgets[name]=w;
}

function buildTray(){
  tray=new Tray(nativeImage.createFromPath(ICON).resize({width:16,height:16}));
  const menu=()=>Menu.buildFromTemplate([
    {label:'Open ORBIX',click:()=>{win.show();win.focus()}},
    {type:'separator'},
    {label:'Start focus session',click:()=>send('focus')},
    {label:"Today's schedule",click:()=>send('schedule')},
    {label:'Start gaming timer',click:()=>send('gaming')},
    {label:'What should I do now?',click:()=>send('whatnow')},
    {type:'separator'},
    {label:'Widgets',submenu:[
      {label:"Today's study",click:()=>widget('study')},
      {label:'Next task',click:()=>widget('next')},
      {label:'Exam countdown',click:()=>widget('exam')},
      {label:'Gaming time',click:()=>widget('game')},
      {label:'Close all widgets',click:()=>{Object.values(widgets).forEach(w=>!w.isDestroyed()&&w.close());widgets={}}}
    ]},
    {label:notifPaused?'Resume notifications':'Pause notifications',type:'checkbox',checked:notifPaused,
     click:()=>{notifPaused=!notifPaused;send(notifPaused?'mute':'unmute');tray.setContextMenu(menu())}},
    {type:'separator'},
    {label:'Exit',click:()=>{quitting=true;app.quit()}}
  ]);
  tray.setToolTip('ORBIX — study smart, play better');
  tray.setContextMenu(menu());
  tray.on('double-click',()=>{win.show();win.focus()});
}

if(!app.requestSingleInstanceLock()){ app.quit() } else {
  app.on('second-instance',()=>{ if(win){ win.show(); win.focus() } });
  app.whenReady().then(()=>{
    createWindow(); buildTray();
    globalShortcut.register('Control+Shift+S',()=>send('study'));
    globalShortcut.register('Control+Shift+G',()=>send('gaming'));
    globalShortcut.register('Control+Shift+F',()=>send('focus'));
    globalShortcut.register('Control+Shift+T',()=>send('schedule'));
  });
}
app.on('before-quit',()=>{quitting=true});
app.on('will-quit',()=>globalShortcut.unregisterAll());
app.on('window-all-closed',()=>{ /* stay in the tray */ });
ipcMain.on('sf-quit',()=>{quitting=true;app.quit()});
