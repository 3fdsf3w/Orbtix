/* Copies ../app into ./www so Capacitor can bundle it. */
const fs=require('fs'),path=require('path');
const src=path.join(__dirname,'..','app'),dst=path.join(__dirname,'www');
function cp(a,b){
  fs.mkdirSync(b,{recursive:true});
  for(const f of fs.readdirSync(a)){
    if(f==='app.js') continue;              // already inlined into index.html
    const s=path.join(a,f),d=path.join(b,f);
    fs.statSync(s).isDirectory()?cp(s,d):fs.copyFileSync(s,d);
  }
}
fs.rmSync(dst,{recursive:true,force:true});
cp(src,dst);
console.log('www/ ready');
