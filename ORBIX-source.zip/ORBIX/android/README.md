# ORBIX for Android

    npm install
    npm run init      # copy app into www/ + create the native project
    npm run open      # Android Studio → Run on device, or Build > Build APK
    npm run sync      # after any edit to ../app

The layout switches automatically below 820px: the sidebar becomes a bottom tab bar
(Dashboard · Schedule · Focus · Gaming · Analytics · More) and content reflows to one column.
Safe-area insets are respected, so nothing hides under the status or gesture bars.

Reminders use the WebView while the app is open. For notifications that fire when the app is
closed, add @capacitor/local-notifications scheduling in a small hook — the dependency is
already in package.json.

No internet permission is needed; the app never calls out.
